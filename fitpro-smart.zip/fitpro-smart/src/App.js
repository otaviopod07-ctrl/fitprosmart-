import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";

/* ─────────────────────────────────────────────────────────────────────────────
   GLOBAL STYLES  (injected once)
───────────────────────────────────────────────────────────────────────────── */
const injectStyles = () => {
  if (document.getElementById("apex-styles")) return;
  const link = document.createElement("link");
  link.href = "https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;0,800;0,900;1,700&family=DM+Sans:wght@300;400;500;600&display=swap";
  link.rel = "stylesheet";
  document.head.appendChild(link);

  const style = document.createElement("style");
  style.id = "apex-styles";
  style.textContent = `
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    ::-webkit-scrollbar { width: 0; }
    body { background: #05080A; overscroll-behavior: none; -webkit-font-smoothing: antialiased; }

    @keyframes fadeUp   { from { opacity:0; transform:translateY(24px);} to { opacity:1; transform:translateY(0);} }
    @keyframes fadeIn   { from { opacity:0; } to { opacity:1; } }
    @keyframes scaleIn  { from { opacity:0; transform:scale(.92);} to { opacity:1; transform:scale(1);} }
    @keyframes ticker   { from { transform:translateX(100%); } to { transform:translateX(-100%); } }
    @keyframes pulseRing {
      0%   { transform:scale(1);    opacity:.7; }
      100% { transform:scale(1.6);  opacity:0;  }
    }
    @keyframes shimmer {
      0%   { background-position:-200% center; }
      100% { background-position: 200% center; }
    }
    @keyframes progressFill {
      from { width: 0%; }
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    @keyframes float {
      0%,100% { transform:translateY(0px); }
      50%     { transform:translateY(-6px); }
    }

    .apex-btn { transition: transform .15s ease, box-shadow .15s ease, opacity .15s ease; }
    .apex-btn:active { transform: scale(.96) !important; }

    .ex-card { transition: background .25s ease, border-color .25s ease, transform .2s ease; }
    .ex-card:active { transform: scale(.985); }

    .nav-item { transition: color .2s ease, background .2s ease; }
    .history-row { transition: background .2s ease; }
    .history-row:hover { background: rgba(255,255,255,.03) !important; }
  `;
  document.head.appendChild(style);
};

/* ─────────────────────────────────────────────────────────────────────────────
   DESIGN TOKENS  (C untouched — only extended)
───────────────────────────────────────────────────────────────────────────── */
const C = {
  /* ── ORIGINAL (untouched) ── */
  bg: "#05080A", surface: "#0B1015", card: "#12181F", border: "#1D262F",
  accent: "#00E5FF", success: "#00FF88", text: "#F0F4F8", textMuted: "#647D8B",
  grad: "linear-gradient(135deg, #00E5FF 0%, #0077FF 100%)",
  /* ── EXTENSIONS ── */
  cardHover: "#161E27",
  accentGlow: "rgba(0,229,255,.18)",
  successGlow: "rgba(0,255,136,.16)",
  warn: "#FF6B2B",
  warnGlow: "rgba(255,107,43,.16)",
  gold: "#FFD166",
  overlay: "rgba(5,8,10,.92)",
  gradSuccess: "linear-gradient(135deg,#00FF88 0%,#00CC6A 100%)",
  gradWarn:    "linear-gradient(135deg,#FF6B2B 0%,#FF3B5C 100%)",
  gradGold:    "linear-gradient(135deg,#FFD166 0%,#FF9F1C 100%)",
  fontDisplay: "'Barlow Condensed', sans-serif",
  fontBody:    "'DM Sans', sans-serif",
};

/* ─────────────────────────────────────────────────────────────────────────────
   WORKOUT CATALOGUE  (purely additive UI data)
───────────────────────────────────────────────────────────────────────────── */
const WORKOUT_TYPES = {
  A: { label:"Peito + Tríceps", emoji:"💪", color:C.accent,   exercises:[
    { id:1,  name:"Supino Reto",       sets:"4×10", muscle:"Peitoral"  },
    { id:2,  name:"Supino Inclinado",  sets:"3×12", muscle:"Peitoral Superior" },
    { id:3,  name:"Crossover",         sets:"3×15", muscle:"Peitoral"  },
  ]},
  B: { label:"Costas + Bíceps", emoji:"🦅", color:"#A78BFA", exercises:[
    { id:4,  name:"Puxada Frontal",    sets:"4×10", muscle:"Dorsais"   },
    { id:5,  name:"Remada Curvada",    sets:"4×10", muscle:"Dorsais"   },
    { id:6,  name:"Rosca Direta",      sets:"4×12", muscle:"Bíceps"    },
  ]},
  C: { label:"Pernas + Glúteos", emoji:"🦵", color:C.warn,   exercises:[
    { id:7,  name:"Agachamento",       sets:"4×10", muscle:"Quadríceps"},
    { id:8,  name:"Leg Press",         sets:"4×12", muscle:"Quadríceps"},
    { id:9,  name:"Mesa Flexora",      sets:"3×12", muscle:"Posterior" },
  ]},
};

const MOTIVATIONS = [
  "A dor de hoje é o shape de amanhã.",
  "Cada rep é uma escolha. Escolha forte.",
  "Consistência vence intensidade.",
  "Não existe atalho. Existe treino.",
  "Seu corpo entrega o que sua mente exige.",
];

/* ─────────────────────────────────────────────────────────────────────────────
   ORIGINAL ENGINE — useApexIntelligence  (ZERO alterações)
───────────────────────────────────────────────────────────────────────────── */
function useApexIntelligence() {
  const [history, setHistory] = useState(() => JSON.parse(localStorage.getItem("@APEX:history") || "[]"));
  const [exerciseStats, setExerciseStats] = useState(() => JSON.parse(localStorage.getItem("@APEX:exercise_stats") || "{}"));
  const [activeSession, setActiveSession] = useState(() => {
    const saved = localStorage.getItem("@APEX:active_session");
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    localStorage.setItem("@APEX:history", JSON.stringify(history));
    localStorage.setItem("@APEX:exercise_stats", JSON.stringify(exerciseStats));
    localStorage.setItem("@APEX:active_session", JSON.stringify(activeSession));
  }, [history, exerciseStats, activeSession]);

  const startWorkout = useCallback((type) => {
    setActiveSession({
      type,
      startTime: Date.now(),
      completedExercises: [],
      date: new Date().toISOString().split('T')[0]
    });
  }, []);

  const toggleExercise = useCallback((exerciseId, exerciseName) => {
    if (!activeSession) return;
    setActiveSession(prev => {
      const isDone = prev.completedExercises.includes(exerciseId);
      const newList = isDone
        ? prev.completedExercises.filter(id => id !== exerciseId)
        : [...prev.completedExercises, exerciseId];
      return { ...prev, completedExercises: newList };
    });
    setExerciseStats(prev => ({
      ...prev,
      [exerciseId]: {
        name: exerciseName,
        lastCompleted: Date.now(),
        totalCompletions: (prev[exerciseId]?.totalCompletions || 0) + 1
      }
    }));
  }, [activeSession]);

  const finishWorkout = useCallback(() => {
    if (!activeSession) return;
    const endTime = Date.now();
    const durationMinutes = Math.floor((endTime - activeSession.startTime) / 60000);
    const sessionFinal = {
      ...activeSession,
      endTime,
      durationMinutes,
      totalExercises: activeSession.completedExercises.length,
      id: `session_${Date.now()}`
    };
    setHistory(prev => [sessionFinal, ...prev]);
    setActiveSession(null);
    return sessionFinal;
  }, [activeSession]);

  const streakData = useMemo(() => {
    if (history.length === 0) return { current: 0, best: 0 };
    const dates = [...new Set(history.map(h => h.date))].sort().reverse();
    let current = 0, best = 0, tempStreak = 0;
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    if (dates[0] !== today && dates[0] !== yesterday) current = 0;
    for (let i = 0; i < dates.length; i++) {
      const d1 = new Date(dates[i]);
      const d2 = new Date(dates[i + 1]);
      const diff = (d1 - d2) / (1000 * 60 * 60 * 24);
      if (diff === 1) { tempStreak++; }
      else {
        best = Math.max(best, tempStreak + 1);
        if (i === 0) current = tempStreak + 1;
        tempStreak = 0;
      }
    }
    return { current: current || (dates[0] === today || dates[0] === yesterday ? 1 : 0), best: Math.max(best, current) };
  }, [history]);

  return { activeSession, history, exerciseStats, streakData, startWorkout, toggleExercise, finishWorkout };
}

/* ─────────────────────────────────────────────────────────────────────────────
   UI COMPONENTS  (100% additive)
───────────────────────────────────────────────────────────────────────────── */

/** Live workout timer */
function LiveTimer({ startTime }) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    const iv = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 1000)), 1000);
    return () => clearInterval(iv);
  }, [startTime]);
  const m = String(Math.floor(elapsed / 60)).padStart(2,"0");
  const s = String(elapsed % 60).padStart(2,"0");
  return <span style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:28, letterSpacing:2, color:C.accent }}>{m}:{s}</span>;
}

/** Animated progress bar */
function ProgressBar({ pct, color=C.accent, height=4 }) {
  return (
    <div style={{ width:"100%", height, background:C.border, borderRadius:99, overflow:"hidden" }}>
      <div style={{
        height:"100%", width:`${pct}%`, borderRadius:99,
        background:`linear-gradient(90deg,${color},${color}aa)`,
        animation:"progressFill .6s ease forwards",
        transition:"width .4s ease",
        boxShadow:`0 0 8px ${color}88`,
      }}/>
    </div>
  );
}

/** Ring stat badge */
function RingStat({ value, label, color=C.accent, size=72 }) {
  const r = (size-8)/2, circ = 2*Math.PI*r;
  const pct = Math.min(value / Math.max(value,10), 1);
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
      <div style={{ position:"relative", width:size, height:size }}>
        <svg width={size} height={size} style={{ transform:"rotate(-90deg)" }}>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={C.border} strokeWidth={5}/>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={5}
            strokeDasharray={`${pct*circ} ${circ}`} strokeLinecap="round"
            style={{ transition:"stroke-dasharray .8s ease", filter:`drop-shadow(0 0 4px ${color})` }}/>
        </svg>
        <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center" }}>
          <span style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, color:C.text }}>{value}</span>
        </div>
      </div>
      <span style={{ fontFamily:C.fontBody, fontSize:10, fontWeight:600, color:C.textMuted, letterSpacing:1, textTransform:"uppercase" }}>{label}</span>
    </div>
  );
}

/** Top ambient header bar */
function AppHeader({ streakData, tab, setTab }) {
  const tabs = [
    { id:"home",    icon:"⚡", label:"Início"   },
    { id:"session", icon:"🏋️",  label:"Treino"   },
    { id:"history", icon:"📊", label:"Histórico"},
  ];
  return (
    <>
      {/* Top bar */}
      <div style={{
        position:"sticky", top:0, zIndex:100,
        background:`${C.bg}e8`, backdropFilter:"blur(20px)",
        borderBottom:`1px solid ${C.border}`,
        padding:"14px 20px",
        display:"flex", alignItems:"center", justifyContent:"space-between",
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <div style={{
            width:34, height:34, borderRadius:10,
            background:C.grad, display:"flex", alignItems:"center",
            justifyContent:"center", fontSize:16,
            boxShadow:`0 0 16px ${C.accentGlow}`,
          }}>⚡</div>
          <div>
            <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:20, letterSpacing:.5, color:C.text, lineHeight:1 }}>
              APEX<span style={{ color:C.accent }}>FIT</span>
            </p>
            <p style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted }}>Performance Engine</p>
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          {streakData.current > 0 && (
            <div style={{
              background:C.warnGlow, border:`1px solid ${C.warn}44`,
              borderRadius:20, padding:"4px 12px",
              display:"flex", alignItems:"center", gap:5,
            }}>
              <span style={{ fontSize:13 }}>🔥</span>
              <span style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:15, color:C.warn }}>{streakData.current}</span>
            </div>
          )}
          <div style={{
            width:36, height:36, borderRadius:"50%",
            background:`linear-gradient(135deg,${C.warn},${C.accent})`,
            display:"flex", alignItems:"center", justifyContent:"center",
            fontFamily:C.fontDisplay, fontWeight:900, fontSize:16, color:C.bg,
          }}>A</div>
        </div>
      </div>

      {/* Motivation ticker */}
      <div style={{
        background:C.surface, borderBottom:`1px solid ${C.border}`,
        overflow:"hidden", height:30,
        display:"flex", alignItems:"center",
      }}>
        <div style={{
          whiteSpace:"nowrap",
          animation:"ticker 22s linear infinite",
          fontFamily:C.fontDisplay, fontWeight:700, fontSize:12,
          letterSpacing:2, color:C.textMuted, textTransform:"uppercase",
        }}>
          {MOTIVATIONS.join("   ·   ")}   ·   {MOTIVATIONS.join("   ·   ")}
        </div>
      </div>

      {/* Nav */}
      <div style={{
        display:"flex", background:C.surface,
        borderBottom:`1px solid ${C.border}`,
      }}>
        {tabs.map(t => (
          <button key={t.id} className="nav-item"
            onClick={() => setTab(t.id)}
            style={{
              flex:1, padding:"10px 0", border:"none", cursor:"pointer",
              background:"transparent",
              borderBottom:`2px solid ${tab===t.id ? C.accent : "transparent"}`,
              display:"flex", flexDirection:"column", alignItems:"center", gap:2,
              color: tab===t.id ? C.accent : C.textMuted,
            }}>
            <span style={{ fontSize:16 }}>{t.icon}</span>
            <span style={{ fontFamily:C.fontBody, fontWeight:600, fontSize:10, letterSpacing:.5 }}>{t.label}</span>
          </button>
        ))}
      </div>
    </>
  );
}

/** Home tab */
function HomeTab({ streakData, history, startWorkout, tab, setTab }) {
  const totalWorkouts = history.length;
  const totalMinutes  = history.reduce((a,h) => a + (h.durationMinutes||0), 0);
  const today = new Date().toISOString().split('T')[0];
  const trainedToday = history.some(h => h.date === today);
  const motivation = MOTIVATIONS[new Date().getDate() % MOTIVATIONS.length];

  return (
    <div style={{ padding:"20px 16px 100px", display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease" }}>

      {/* Hero greeting */}
      <div style={{
        background:`linear-gradient(135deg, ${C.card} 0%, #0D1A24 100%)`,
        border:`1px solid ${C.border}`, borderRadius:20, padding:24,
        position:"relative", overflow:"hidden",
      }}>
        <div style={{
          position:"absolute", top:-40, right:-40, width:160, height:160,
          borderRadius:"50%", background:C.accentGlow, filter:"blur(40px)", pointerEvents:"none",
        }}/>
        <p style={{ fontFamily:C.fontBody, fontSize:12, color:C.textMuted, marginBottom:4 }}>
          {new Date().toLocaleDateString("pt-BR",{ weekday:"long", day:"numeric", month:"long" })}
        </p>
        <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:32, letterSpacing:.5, lineHeight:1.1, marginBottom:8 }}>
          {trainedToday ? "MISSÃO CUMPRIDA" : "HORA DE TREINAR"}
          <br/><span style={{ color:C.accent }}>ATLETA. ⚡</span>
        </p>
        <p style={{ fontFamily:C.fontBody, fontSize:13, color:C.textMuted, lineHeight:1.6, marginBottom:20 }}>
          "{motivation}"
        </p>
        {!trainedToday && (
          <button className="apex-btn"
            onClick={() => { setTab("session"); }}
            style={{
              background:C.grad, border:"none", borderRadius:14,
              padding:"14px 28px", cursor:"pointer",
              fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, letterSpacing:1,
              color:C.bg, boxShadow:`0 8px 24px ${C.accentGlow}`,
            }}>
            INICIAR TREINO ⚡
          </button>
        )}
        {trainedToday && (
          <div style={{
            display:"inline-flex", alignItems:"center", gap:8,
            background:C.successGlow, border:`1px solid ${C.success}44`,
            borderRadius:12, padding:"10px 18px",
          }}>
            <span style={{ fontSize:18 }}>✅</span>
            <span style={{ fontFamily:C.fontDisplay, fontWeight:700, fontSize:16, color:C.success }}>
              Treino feito hoje!
            </span>
          </div>
        )}
      </div>

      {/* ── ORIGINAL STREAK SECTION (visual upgrade only) ── */}
      <section style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <div style={{
          background:C.card, padding:20, borderRadius:18,
          border:`1px solid ${C.border}`, position:"relative", overflow:"hidden",
        }}>
          {streakData.current > 0 && (
            <div style={{
              position:"absolute", top:10, right:10,
              width:40, height:40, borderRadius:"50%",
              background:`${C.warn}22`, border:`1px solid ${C.warn}44`,
              display:"flex", alignItems:"center", justifyContent:"center", fontSize:18,
            }}>🔥</div>
          )}
          <p style={{ color:C.textMuted, fontSize:10, fontWeight:800, fontFamily:C.fontBody, letterSpacing:1, marginBottom:6 }}>STREAK ATUAL</p>
          <span style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:36, color:streakData.current>0?C.warn:C.textMuted }}>
            {streakData.current}
          </span>
          <p style={{ fontFamily:C.fontBody, fontSize:11, color:C.textMuted, marginTop:2 }}>dias seguidos</p>
          <div style={{ marginTop:10 }}>
            <ProgressBar pct={Math.min(streakData.current*10,100)} color={C.warn}/>
          </div>
        </div>

        <div style={{
          background:C.card, padding:20, borderRadius:18,
          border:`1px solid ${C.border}`, position:"relative", overflow:"hidden",
        }}>
          <div style={{
            position:"absolute", top:10, right:10,
            width:40, height:40, borderRadius:"50%",
            background:`${C.gold}22`, border:`1px solid ${C.gold}44`,
            display:"flex", alignItems:"center", justifyContent:"center", fontSize:18,
          }}>🏆</div>
          <p style={{ color:C.textMuted, fontSize:10, fontWeight:800, fontFamily:C.fontBody, letterSpacing:1, marginBottom:6 }}>MELHOR MARCA</p>
          <span style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:36, color:C.accent }}>
            {streakData.best}
          </span>
          <p style={{ fontFamily:C.fontBody, fontSize:11, color:C.textMuted, marginTop:2 }}>dias de recorde</p>
          <div style={{ marginTop:10 }}>
            <ProgressBar pct={Math.min(streakData.best*10,100)} color={C.accent}/>
          </div>
        </div>
      </section>

      {/* Stats row */}
      <div style={{
        background:C.card, border:`1px solid ${C.border}`, borderRadius:18,
        padding:"20px 16px",
        display:"flex", justifyContent:"space-around", alignItems:"center",
      }}>
        <RingStat value={totalWorkouts} label="Treinos"   color={C.accent}/>
        <div style={{ width:1, height:50, background:C.border }}/>
        <RingStat value={totalMinutes}  label="Minutos"   color={C.warn}/>
        <div style={{ width:1, height:50, background:C.border }}/>
        <RingStat value={streakData.best} label="Recorde" color={C.gold}/>
      </div>

      {/* Choose workout cards */}
      <div>
        <p style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, letterSpacing:.5, marginBottom:12 }}>
          ESCOLHA SEU TREINO
        </p>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {Object.entries(WORKOUT_TYPES).map(([key, wk]) => (
            <button key={key} className="apex-btn ex-card"
              onClick={() => { startWorkout(key); setTab("session"); }}
              style={{
                background:C.card, border:`1px solid ${C.border}`,
                borderRadius:16, padding:"16px 20px", cursor:"pointer",
                display:"flex", alignItems:"center", justifyContent:"space-between",
                width:"100%", textAlign:"left",
              }}>
              <div style={{ display:"flex", alignItems:"center", gap:14 }}>
                <div style={{
                  width:48, height:48, borderRadius:14,
                  background:`${wk.color}18`, border:`1px solid ${wk.color}44`,
                  display:"flex", alignItems:"center", justifyContent:"center", fontSize:24,
                }}>
                  {wk.emoji}
                </div>
                <div>
                  <p style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, color:C.text, letterSpacing:.3 }}>
                    TREINO {key}
                  </p>
                  <p style={{ fontFamily:C.fontBody, fontSize:12, color:C.textMuted }}>{wk.label}</p>
                </div>
              </div>
              <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:4 }}>
                <span style={{ fontFamily:C.fontBody, fontSize:11, color:wk.color, fontWeight:600 }}>
                  {wk.exercises.length} exerc.
                </span>
                <span style={{ fontSize:18, color:C.textMuted }}>›</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/** Session (active workout) tab — wraps original logic */
function SessionTab({ activeSession, toggleExercise, finishWorkout, setShowSummary, startWorkout, setTab }) {
  const wk = activeSession ? WORKOUT_TYPES[activeSession.type] : null;
  const exercises = wk ? wk.exercises : [{ id:1, name:"Exercício 1", sets:"—", muscle:"—" },
                                          { id:2, name:"Exercício 2", sets:"—", muscle:"—" },
                                          { id:3, name:"Exercício 3", sets:"—", muscle:"—" }];
  const total    = exercises.length;
  const done     = activeSession ? activeSession.completedExercises.length : 0;
  const pct      = total > 0 ? Math.round((done/total)*100) : 0;

  if (!activeSession) return (
    <div style={{ padding:"40px 20px", display:"flex", flexDirection:"column", alignItems:"center", gap:20, animation:"fadeUp .4s ease" }}>
      <div style={{ fontSize:64 }}>🏋️</div>
      <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:28, textAlign:"center" }}>
        NENHUM TREINO<br/><span style={{ color:C.accent }}>ATIVO</span>
      </p>
      <p style={{ fontFamily:C.fontBody, fontSize:14, color:C.textMuted, textAlign:"center" }}>
        Vá para Início e escolha um treino para começar.
      </p>
      <button className="apex-btn"
        onClick={() => setTab("home")}
        style={{
          background:C.grad, border:"none", borderRadius:14,
          padding:"14px 32px", cursor:"pointer",
          fontFamily:C.fontDisplay, fontWeight:800, fontSize:18,
          color:C.bg, letterSpacing:1,
        }}>
        IR PARA INÍCIO
      </button>
    </div>
  );

  return (
    <div style={{ padding:"20px 16px 100px", display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .3s ease" }}>

      {/* Session header — original logic preserved */}
      <div style={{
        background:`linear-gradient(135deg,${C.card},#0D1A24)`,
        border:`1px solid ${wk?.color || C.border}44`,
        borderRadius:20, padding:20, position:"relative", overflow:"hidden",
      }}>
        <div style={{
          position:"absolute", top:-30, right:-30, width:120, height:120,
          borderRadius:"50%", background:`${wk?.color || C.accent}18`, filter:"blur(30px)",
        }}/>
        {/* pulse ring */}
        <div style={{ position:"absolute", top:20, right:20 }}>
          <div style={{
            width:12, height:12, borderRadius:"50%", background:C.success,
            boxShadow:`0 0 0 0 ${C.success}`, position:"relative",
          }}>
            <div style={{
              position:"absolute", inset:-4, borderRadius:"50%",
              border:`2px solid ${C.success}`,
              animation:"pulseRing 1.4s ease infinite",
            }}/>
          </div>
        </div>

        <p style={{ fontFamily:C.fontBody, fontSize:11, color:C.textMuted, marginBottom:4 }}>EM ANDAMENTO</p>
        <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:26, color:C.text, marginBottom:2 }}>
          TREINO {activeSession.type} {wk?.emoji}
        </p>
        <p style={{ fontFamily:C.fontBody, fontSize:13, color:C.textMuted, marginBottom:16 }}>
          {wk?.label}
        </p>

        {/* timer + progress */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
          <div>
            <p style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted, marginBottom:2 }}>TEMPO</p>
            <LiveTimer startTime={activeSession.startTime}/>
          </div>
          <div style={{ textAlign:"right" }}>
            <p style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted, marginBottom:2 }}>PROGRESSO</p>
            <span style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:28, color:wk?.color||C.accent }}>
              {done}/{total}
            </span>
          </div>
        </div>
        <ProgressBar pct={pct} color={wk?.color||C.accent} height={6}/>
        <div style={{ display:"flex", justifyContent:"space-between", marginTop:4 }}>
          <span style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted }}>{pct}% concluído</span>
          {pct===100 && <span style={{ fontFamily:C.fontBody, fontSize:10, color:C.success, fontWeight:600 }}>🎉 Completo!</span>}
        </div>
      </div>

      {/* ── ORIGINAL exercise list (logic unchanged, UI upgraded) ── */}
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {exercises.map((ex, idx) => {
          const isDone = activeSession.completedExercises.includes(ex.id);
          return (
            <div key={ex.id} className="ex-card"
              onClick={() => toggleExercise(ex.id, ex.name)}
              style={{
                background: isDone ? `${C.success}12` : C.card,
                padding:"16px 18px", borderRadius:16,
                border:`1.5px solid ${isDone ? C.success+"66" : C.border}`,
                cursor:"pointer", display:"flex", alignItems:"center", gap:14,
                animation:`fadeUp .3s ease ${idx*.07}s both`,
              }}>
              {/* checkbox */}
              <div style={{
                width:36, height:36, borderRadius:10, flexShrink:0,
                background: isDone ? C.success : C.surface,
                border:`2px solid ${isDone ? C.success : C.border}`,
                display:"flex", alignItems:"center", justifyContent:"center",
                transition:"all .25s ease",
                boxShadow: isDone ? `0 0 12px ${C.successGlow}` : "none",
                fontFamily:C.fontDisplay, fontWeight:900, fontSize:16,
                color: isDone ? C.bg : C.textMuted,
              }}>
                {isDone ? "✓" : idx+1}
              </div>
              <div style={{ flex:1 }}>
                <p style={{
                  fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, letterSpacing:.3,
                  color: isDone ? C.textMuted : C.text,
                  textDecoration: isDone ? "line-through" : "none",
                }}>
                  {ex.name}
                </p>
                <div style={{ display:"flex", gap:10, marginTop:2 }}>
                  <span style={{ fontFamily:C.fontBody, fontSize:11, color:wk?.color||C.accent, fontWeight:600 }}>
                    {ex.sets}
                  </span>
                  <span style={{ fontFamily:C.fontBody, fontSize:11, color:C.textMuted }}>
                    {ex.muscle}
                  </span>
                </div>
              </div>
              {isDone && (
                <div style={{
                  background:C.successGlow, borderRadius:8, padding:"4px 10px",
                }}>
                  <span style={{ fontFamily:C.fontBody, fontSize:11, color:C.success, fontWeight:600 }}>✅ Feito</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ── ORIGINAL finishWorkout call (preserved exactly) ── */}
      <button className="apex-btn"
        onClick={() => { finishWorkout(); setShowSummary(true); }}
        style={{
          width:"100%", padding:"18px", borderRadius:16, border:"none",
          background: done > 0 ? C.gradSuccess : C.surface,
          cursor:"pointer",
          fontFamily:C.fontDisplay, fontWeight:900, fontSize:20, letterSpacing:1,
          color: done > 0 ? C.bg : C.textMuted,
          boxShadow: done > 0 ? `0 8px 24px ${C.successGlow}` : "none",
          transition:"all .3s ease",
        }}>
        FINALIZAR TREINO {done > 0 ? "✓" : ""}
      </button>
    </div>
  );
}

/** History tab — wraps original history array */
function HistoryTab({ history }) {
  if (history.length === 0) return (
    <div style={{ padding:"60px 20px", display:"flex", flexDirection:"column", alignItems:"center", gap:16, animation:"fadeUp .4s ease" }}>
      <div style={{ fontSize:56 }}>📊</div>
      <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:26, textAlign:"center" }}>
        SEM HISTÓRICO<br/><span style={{ color:C.accent }}>AINDA</span>
      </p>
      <p style={{ fontFamily:C.fontBody, fontSize:13, color:C.textMuted, textAlign:"center" }}>
        Complete seu primeiro treino para ver seus dados aqui.
      </p>
    </div>
  );

  const totalMin = history.reduce((a,h)=>a+(h.durationMinutes||0),0);
  const totalEx  = history.reduce((a,h)=>a+(h.totalExercises||0),0);

  return (
    <div style={{ padding:"20px 16px 100px", display:"flex", flexDirection:"column", gap:16, animation:"fadeUp .4s ease" }}>

      {/* Summary cards */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10 }}>
        {[
          { label:"Sessões",   value:history.length, color:C.accent },
          { label:"Minutos",   value:totalMin,        color:C.warn   },
          { label:"Exercícios",value:totalEx,         color:C.success},
        ].map(s => (
          <div key={s.label} style={{
            background:C.card, border:`1px solid ${C.border}`,
            borderRadius:16, padding:"14px 12px", textAlign:"center",
          }}>
            <p style={{ fontFamily:C.fontDisplay, fontWeight:900, fontSize:28, color:s.color }}>{s.value}</p>
            <p style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted, letterSpacing:.5, textTransform:"uppercase" }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* ── ORIGINAL history.slice(0,5) — logic intact, UI upgraded ── */}
      <div>
        <p style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, letterSpacing:.5, marginBottom:12 }}>
          HISTÓRICO DE PERFORMANCE
        </p>
        <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
          {history.slice(0, 5).map((session, idx) => {
            const wk = WORKOUT_TYPES[session.type];
            return (
              <div key={session.id} className="history-row"
                style={{
                  background:C.card, border:`1px solid ${C.border}`,
                  borderRadius:16, padding:"14px 18px",
                  display:"flex", justifyContent:"space-between", alignItems:"center",
                  animation:`fadeUp .3s ease ${idx*.06}s both`,
                }}>
                <div style={{ display:"flex", alignItems:"center", gap:12 }}>
                  <div style={{
                    width:42, height:42, borderRadius:12,
                    background:`${wk?.color||C.accent}18`,
                    display:"flex", alignItems:"center", justifyContent:"center",
                    fontSize:20,
                  }}>
                    {wk?.emoji || "🏋️"}
                  </div>
                  <div>
                    <p style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:17, color:C.text }}>
                      TREINO {session.type}
                    </p>
                    <p style={{ fontFamily:C.fontBody, fontSize:12, color:C.textMuted }}>
                      {session.date} · {session.durationMinutes} min
                    </p>
                  </div>
                </div>
                <div style={{ textAlign:"right" }}>
                  <p style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:18, color:wk?.color||C.accent }}>
                    {session.totalExercises} exs
                  </p>
                  <p style={{ fontFamily:C.fontBody, fontSize:10, color:C.textMuted }}>concluídos</p>
                </div>
              </div>
            );
          })}
        </div>
        {history.length > 5 && (
          <p style={{ fontFamily:C.fontBody, fontSize:12, color:C.textMuted, textAlign:"center", marginTop:12 }}>
            + {history.length - 5} sessões anteriores
          </p>
        )}
      </div>
    </div>
  );
}

/** ── ORIGINAL showSummary modal — upgraded visuals, zero logic change ── */
function SummaryModal({ show, onClose, streakData }) {
  if (!show) return null;
  return (
    <div style={{
      position:"fixed", inset:0, background:C.overlay, zIndex:1000,
      display:"flex", alignItems:"center", justifyContent:"center",
      padding:20, animation:"fadeIn .2s ease",
    }}>
      <div style={{
        background:C.card, padding:36, borderRadius:28, textAlign:"center",
        width:"100%", maxWidth:380,
        border:`2px solid ${C.accent}`,
        boxShadow:`0 0 60px ${C.accentGlow}`,
        animation:"scaleIn .3s ease",
      }}>
        {/* glow ring */}
        <div style={{ position:"relative", display:"inline-block", marginBottom:8 }}>
          <div style={{
            width:80, height:80, borderRadius:"50%",
            background:`linear-gradient(135deg,${C.accent},#0077FF)`,
            display:"flex", alignItems:"center", justifyContent:"center",
            fontSize:36, margin:"0 auto",
            boxShadow:`0 0 40px ${C.accentGlow}`,
            animation:"float 3s ease infinite",
          }}>⚡</div>
        </div>

        <h2 style={{
          fontFamily:C.fontDisplay, fontWeight:900, fontSize:32, letterSpacing:.5,
          margin:"16px 0 8px", color:C.text,
        }}>TREINO CONCLUÍDO!</h2>

        <p style={{ fontFamily:C.fontBody, fontSize:14, color:C.textMuted, lineHeight:1.6, marginBottom:20 }}>
          Sua constância é o que constrói seu resultado.
        </p>

        {streakData.current > 0 && (
          <div style={{
            background:C.warnGlow, border:`1px solid ${C.warn}44`,
            borderRadius:14, padding:"12px 20px", marginBottom:20,
            display:"flex", alignItems:"center", justifyContent:"center", gap:8,
          }}>
            <span style={{ fontSize:22 }}>🔥</span>
            <span style={{ fontFamily:C.fontDisplay, fontWeight:800, fontSize:20, color:C.warn }}>
              {streakData.current} DIAS DE STREAK!
            </span>
          </div>
        )}

        <button className="apex-btn"
          onClick={onClose}
          style={{
            width:"100%", padding:"16px", borderRadius:14, border:"none",
            background:C.grad, cursor:"pointer",
            fontFamily:C.fontDisplay, fontWeight:900, fontSize:20, letterSpacing:1,
            color:C.bg, boxShadow:`0 8px 24px ${C.accentGlow}`,
          }}>
          BORAAA 🚀
        </button>
      </div>
    </div>
  );
}

/* ─────────────────────────────────────────────────────────────────────────────
   ROOT — App()
   ORIGINAL startWorkout / toggleExercise / finishWorkout / streakData / history
   ALL called identically. Only the shell around them is upgraded.
───────────────────────────────────────────────────────────────────────────── */
export default function App() {
  injectStyles();

  /* ── ORIGINAL hook call (zero changes) ── */
  const { activeSession, history, streakData, startWorkout, toggleExercise, finishWorkout } = useApexIntelligence();

  /* ── ORIGINAL state (zero changes) ── */
  const [showSummary, setShowSummary] = useState(false);

  /* ── NEW: tab navigation state ── */
  const [tab, setTab] = useState("home");

  // Auto-switch to session tab when a workout starts
  useEffect(() => { if (activeSession) setTab("session"); }, [activeSession]);

  return (
    <div style={{
      background:C.bg, color:C.text,
      minHeight:"100vh",
      fontFamily:C.fontBody,
      maxWidth:480, margin:"0 auto",
      position:"relative",
    }}>
      <AppHeader streakData={streakData} tab={tab} setTab={setTab}/>

      <div style={{ minHeight:"calc(100vh - 140px)" }}>
        {tab === "home" && (
          <HomeTab
            streakData={streakData}
            history={history}
            startWorkout={startWorkout}   /* original fn */
            tab={tab} setTab={setTab}
          />
        )}
        {tab === "session" && (
          <SessionTab
            activeSession={activeSession}        /* original state */
            toggleExercise={toggleExercise}      /* original fn */
            finishWorkout={finishWorkout}         /* original fn */
            setShowSummary={setShowSummary}       /* original state setter */
            startWorkout={startWorkout}
            setTab={setTab}
          />
        )}
        {tab === "history" && (
          <HistoryTab
            history={history}                    /* original state */
          />
        )}
      </div>

      {/* ── ORIGINAL showSummary modal (zero logic change) ── */}
      <SummaryModal
        show={showSummary}
        onClose={() => setShowSummary(false)}    /* original setter */
        streakData={streakData}                  /* original data */
      />
    </div>
  );
}
